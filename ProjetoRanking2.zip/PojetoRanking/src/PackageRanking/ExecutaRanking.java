package PackageRanking;

public class ExecutaRanking {

	public static void main(String[] args) {

		
		RankingGeralAssassino rga = new RankingGeralAssassino();
		RankingGeralMorto rgm = new RankingGeralMorto();
		RankingPartidaAssassino rpa = new RankingPartidaAssassino();
		RankingPartidaMortos rpm = new RankingPartidaMortos();
		
		System.out.println("Ranking Geral Assassinos");
		rga.rga();
		System.out.println();
		System.out.println("Ranking Geral Mortos");
		rgm.rgm();
		System.out.println();

		System.out.println("Ranking Partida Assassinos");
		rpa.rpa();
		System.out.println();

		System.out.println("Ranking Partida Mortos");
		rpm.rpm();
	}

}
