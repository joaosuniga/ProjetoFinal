package PackageRanking;

import java.util.*;

public class RankingPartidaMortos {

	public static String id;
	
	public static void rpm(){


		ParseCSV trasnfereDados = new ParseCSV();
		
		String entradaDados;
		
		trasnfereDados.readCsvFile();
		entradaDados = trasnfereDados.fluxoFinal;
		

		Hashtable<String, Integer> placarMorto = new Hashtable<String, Integer>();
		
		String[] partidas= entradaDados.split("has ended");
		
		for (int j = 0; j < partidas.length; j++) {
			String partida = partidas[j];

			
			String[] linhas = partida.split("\n");
		
		
			for (int i = 0; i < linhas.length; i++) {
				
				String linha = linhas[i];
				
					if (linha.contains("New")) {
						
						String[] dividelinha1 = linha.split(" ");
						
						String idPartida = dividelinha1[5];
						id = idPartida;

					}
					else if(linha.contains("killed")){
							
							String[] divideLinha2 = linha.split(" - ");
							String separaPalavras = divideLinha2[1];
							String[] achaPalavra = separaPalavras.split(" ");
							String nomeAssasino = achaPalavra[0]+ " na partida " +id;
							String nomeMorto = achaPalavra[2]+ " na partida " +id;
							
							if(placarMorto.containsKey(nomeMorto)) {
								placarMorto.put(nomeMorto, placarMorto.get(nomeMorto) + 1);
							}
							else {
								placarMorto.put(nomeMorto, 1);	
							}

						}
						
				}
					
					
			
		
		}
			Iterator<Map.Entry<String, Integer>> it = placarMorto.entrySet().iterator();
			 
			while (it.hasNext()) {
				Map.Entry<String, Integer> jogador = it.next();
	 
				System.out.println(jogador.getKey() + " morreu " + jogador.getValue() + " vez(es)");
					
					
				}
		//for de partidas
	}
}


