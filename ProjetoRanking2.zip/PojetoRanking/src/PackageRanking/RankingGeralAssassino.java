package PackageRanking;

import java.util.Hashtable;
import java.util.*;

public class RankingGeralAssassino {

	public static void rga(){


		ParseCSV trasnfereDados = new ParseCSV();
		
		String entradaDados;
		
		trasnfereDados.readCsvFile();
		entradaDados = trasnfereDados.fluxoFinal;
		
		
		Hashtable<String, Integer> placar = new Hashtable<String, Integer>();
		
		String[] partidas;
		partidas = entradaDados.split("has ended");
		
		for (int j = 0; j < partidas.length; j++) {
			String partida = partidas[j];
		
		
		String[] linhas;
		
		linhas = partida.split("\n");
		
		for (int i = 0; i < linhas.length; i++) {
			
			String linha;
			
			linha = linhas[i];
			
			if (linha.contains("killed")) {
				
				String[] temporario;
				
				temporario = linha.split(" - ");
				
				String[]nomes;
				
				nomes = temporario[1].split(" killed ");
				
				String nomeAssassino, nomeVitima;
				
				nomeAssassino = nomes[0];
				
				nomeVitima = nomes[1].split(" using ")[0];
				
				
				
				if(placar.containsKey(nomeAssassino)) {
					placar.put(nomeAssassino, placar.get(nomeAssassino) + 1);
				}
				else {
					placar.put(nomeAssassino, 1);	
				}
			}
		}
	}
 
		Iterator<Map.Entry<String, Integer>> it = placar.entrySet().iterator();
 
		while (it.hasNext()) {
			Map.Entry<String, Integer> jogador = it.next();
 
			System.out.println(jogador.getKey() + " no total matou " + jogador.getValue() + " vez(es)");
				
				
			}
		}
	}


