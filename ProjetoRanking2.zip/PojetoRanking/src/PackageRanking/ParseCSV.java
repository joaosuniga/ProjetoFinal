package PackageRanking;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class ParseCSV {

	public String fluxoFinal;
	
	public void readCsvFile(){

		try {

		BufferedReader BuffReader = new BufferedReader(new FileReader("c:\\log.txt"));

		String fluxo;
		
		String[] linhas;


		while((fluxo = BuffReader.readLine())!= null){
			
		linhas = fluxo.split(" ");

		for (String celula : linhas) {
			
			fluxoFinal += celula+" ";
			
		}
		fluxoFinal += "\n";
		
		}
		
		BuffReader.close();
		
		} 
		
		catch (FileNotFoundException e) {
			e.printStackTrace();
		} 
		
		catch (IOException ex){
			ex.printStackTrace();
		}

	}

}
	
	
